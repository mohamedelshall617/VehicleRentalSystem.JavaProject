package com.example;

import java.util.ArrayList;

public class User {

    private int userId;
    private String name;
    private String email;
    private String phoneNumber;
    private ArrayList<Booking> bookings;

    public User(int userId, String name, String email, String phoneNumber) {
        if (userId <= 0) {
            throw new IllegalArgumentException("User ID must be positive.");
        }
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("User name cannot be empty.");
        }
        if (email == null || email.isBlank() || !email.contains("@")) {
            throw new IllegalArgumentException("Enter a valid email address.");
        }
        if (phoneNumber == null || phoneNumber.isBlank()) {
            throw new IllegalArgumentException("Phone number cannot be empty.");
        }
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.bookings = new ArrayList<>();
    }

    public int getUserId() {
        return userId;
    }
    
    public String getName() {
        return name;
    }
    
    public String getEmail() {
        return email;
    }
    
    public String getPhoneNumber() {
        return phoneNumber;
    }
    @Override
    public String toString() {
        return this.name;
    }
}
