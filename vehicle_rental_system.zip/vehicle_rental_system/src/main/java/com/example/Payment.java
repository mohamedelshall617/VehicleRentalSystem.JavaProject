package com.example;

public class Payment implements Rentable {
    private int paymentId;
    private Booking booking;
    private double amount;
    private PaymentMethod paymentMethod;
    private boolean isPaid;

    public enum PaymentMethod {
        CREDIT_CARD,
        DEBIT_CARD,
        PAYPAL,
        CASH
    }

    
    public Payment(int paymentId, Booking booking, double amount, PaymentMethod paymentMethod) {
        if (paymentId <= 0) {
            throw new IllegalArgumentException("Payment ID must be positive.");
        }
        if (booking == null) {
            throw new IllegalArgumentException("Payment must be linked to a booking.");
        }
        if (amount <= 0) {
            throw new IllegalArgumentException("Payment amount must be greater than zero.");
        }
        if (paymentMethod == null) {
            throw new IllegalArgumentException("Payment method cannot be null.");
        }
        this.paymentId = paymentId;
        this.booking = booking;
        this.amount = amount;
        this.paymentMethod = paymentMethod;
        this.isPaid = false;
    }
    public void setPaymentMethod(PaymentMethod paymentMethod) {
        if (paymentMethod == null) {
            throw new IllegalArgumentException("Payment method cannot be null.");
        }
        this.paymentMethod = paymentMethod;
    }
    public void rent() {
        if (booking == null || booking.getVehicle() == null) {
            throw new IllegalStateException("Invalid booking. Please check your booking details.");
        }
        if (isPaid) {
            throw new IllegalStateException("This payment has already been completed.");
        }
        Vehicle vehicle = booking.getVehicle();
        if (!vehicle.isAvailable()) {
            throw new IllegalStateException("The selected vehicle is not available for rent.");
        }
        isPaid = true;
        System.out.println("Payment successful. You have rented the " + vehicle.getBrand() + " " + vehicle.getModel() + ".");
    }
    public double calculateTotalAmount() {
        if (booking == null || booking.getVehicle() == null) {
            throw new IllegalStateException("Cannot calculate payment amount for an invalid booking.");
        }
        return booking.calculateTotalPrice();
    }
}
