package com.example;

public class Van extends Vehicle {

    private int numSeats;
    private boolean hasAC;
    public enum Brand { MERCEDES, FORD, VOLKSWAGEN, RAM, TOYOTA }
    public enum Model { SPRINTER, TRANSIT, CRAFTER, PROMASTER, HIACE }
    public Van(int vehicleId, String brand, String model, double priceperday,int numSeats, boolean hasAC, boolean isAvailable) {
        super(vehicleId, brand, model, priceperday, isAvailable);
        this.numSeats = numSeats;
        this.hasAC = hasAC;
    }
    @Override
    void displayinfo() {    
        System.out.println("Van Information:");
        System.out.println("Brand: " + super.getBrand());
        System.out.println("Model: " + super.getModel());
        System.out.println("Price per day: $" + super.getPriceperday());
        System.out.println("Number of seats: " + numSeats);
        System.out.println("Has AC: " + hasAC);
        System.out.println("Is available: " + super.isAvailable());
    }
    @Override
    public String toString() {
        return "Brand: " + super.getBrand() + " Model: " + super.getModel() +
                ", Number of seats=" + numSeats +
                ", Has AC=" + hasAC +
                ", isAvailable=" + super.isAvailable() ;
    }
}
