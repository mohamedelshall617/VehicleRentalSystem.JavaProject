package com.example;

import java.time.LocalDate;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class VehicleRentalApp extends Application {
    private RentableManager manager = new RentableManager();
    private int nextVehicleId = 1;
    private int nextUserId = 1;

    // GUI Components
    private ListView<Vehicle> carList = new ListView<>();
    private ListView<Vehicle> bikeList = new ListView<>();
    private ListView<Vehicle> vanList = new ListView<>();
    private ListView<User> userList = new ListView<>();
    private ListView<Booking> bookingList = new ListView<>();
    private TextArea userDetailsArea = new TextArea();

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Rental Management System");

        TabPane tabPane = new TabPane();
        tabPane.getTabs().add(new Tab("Vehicles", createVehiclePage()));
        tabPane.getTabs().add(new Tab("Users", createUserPage()));
        tabPane.getTabs().add(new Tab("Bookings", createBookingPage()));
        tabPane.getTabs().forEach(t -> t.setClosable(false));

        primaryStage.setScene(new Scene(tabPane, 1200, 800));
        primaryStage.show();
    }

    // ================= 1. VEHICLE PAGE =================
    private VBox createVehiclePage() {
        HBox columns = new HBox(20);
        columns.setPadding(new Insets(20));
        VBox carCol = createVisibleColumn("CARS", carList);
        VBox bikeCol = createVisibleColumn("BIKES", bikeList);
        VBox vanCol = createVisibleColumn("VANS", vanList);
        HBox.setHgrow(carCol, Priority.ALWAYS); HBox.setHgrow(bikeCol, Priority.ALWAYS); HBox.setHgrow(vanCol, Priority.ALWAYS);
        columns.getChildren().addAll(carCol, bikeCol, vanCol);

        Button addBtn = new Button("Add Vehicle");
        Button remBtn = new Button("Remove Selected");
        remBtn.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
        addBtn.setOnAction(e -> openAddVehicleDialog());
        remBtn.setOnAction(e -> handleRemoveVehicle());

        HBox actions = new HBox(20, addBtn, remBtn);
        actions.setAlignment(Pos.CENTER);
        actions.setPadding(new Insets(15));
        return new VBox(10, columns, actions);
    }

    private void openAddVehicleDialog() {
        Dialog<Vehicle> dialog = new Dialog<>();
        dialog.setTitle("Register New Vehicle");
        ButtonType okType = new ButtonType("Add", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(okType, ButtonType.CANCEL);

        GridPane grid = new GridPane(); grid.setHgap(10); grid.setVgap(10); grid.setPadding(new Insets(20));
        ComboBox<String> typeBox = new ComboBox<>(FXCollections.observableArrayList("Car", "Bike", "Van"));
        ComboBox<String> brandBox = new ComboBox<>();
        ComboBox<String> modelBox = new ComboBox<>();
        TextField priceField = new TextField("50.0");
        VBox specificOptions = new VBox(10);

        typeBox.setOnAction(e -> {
            brandBox.getItems().clear(); modelBox.getItems().clear(); specificOptions.getChildren().clear();
            if ("Car".equals(typeBox.getValue())) {
                brandBox.getItems().addAll("Toyota", "BMW", "Tesla", "Honda");
                modelBox.getItems().addAll("Camry", "M3", "Model S", "Civic");
                specificOptions.getChildren().addAll(new Label("Seats:"), new ComboBox<>(FXCollections.observableArrayList(2, 5, 7)), new Label("AC:"), new ComboBox<>(FXCollections.observableArrayList(true, false)), new Label("Transmission:"), new ComboBox<>(FXCollections.observableArrayList(Car.TransmissionType.values())));
            } else if ("Bike".equals(typeBox.getValue())) {
                brandBox.getItems().addAll("Yamaha", "Kawasaki", "Harley");
                modelBox.getItems().addAll("R1", "Ninja", "Iron 883");
                specificOptions.getChildren().addAll(new Label("Type:"), new ComboBox<>(FXCollections.observableArrayList(Bike.VehicleType.values())), new Label("Helmet:"), new ComboBox<>(FXCollections.observableArrayList(true, false)), new Label("Max Speed:"), new TextField("180"));
            } else if ("Van".equals(typeBox.getValue())) {
                brandBox.getItems().addAll("Mercedes", "Ford", "Volkswagen");
                modelBox.getItems().addAll("Sprinter", "Transit", "Crafter");
                specificOptions.getChildren().addAll(new Label("Seats:"), new ComboBox<>(FXCollections.observableArrayList(8, 12, 15)), new Label("AC:"), new ComboBox<>(FXCollections.observableArrayList(true, false)));
            }
            dialog.getDialogPane().getScene().getWindow().sizeToScene();
        });

        grid.add(new Label("Category:"), 0, 0); grid.add(typeBox, 1, 0);
        grid.add(new Label("Brand:"), 0, 1);    grid.add(brandBox, 1, 1);
        grid.add(new Label("Model:"), 0, 2);    grid.add(modelBox, 1, 2);
        grid.add(new Label("Price/Day:"), 0, 3); grid.add(priceField, 1, 3);
        grid.add(specificOptions, 0, 4, 2, 1);
        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(btn -> {
            if (btn == okType && typeBox.getValue() != null) {
                try {
                    double p = Double.parseDouble(priceField.getText());
                    String b = brandBox.getValue(); String m = modelBox.getValue();
                    if ("Car".equals(typeBox.getValue())) return new Car(nextVehicleId++, b, m, p, (int)((ComboBox)specificOptions.getChildren().get(1)).getValue(), (boolean)((ComboBox)specificOptions.getChildren().get(3)).getValue(), (Car.TransmissionType)((ComboBox)specificOptions.getChildren().get(5)).getValue(), true);
                    else if ("Bike".equals(typeBox.getValue())) return new Bike(nextVehicleId++, b, m, p, (Bike.VehicleType)((ComboBox)specificOptions.getChildren().get(1)).getValue(), true, (boolean)((ComboBox)specificOptions.getChildren().get(3)).getValue(), Integer.parseInt(((TextField)specificOptions.getChildren().get(5)).getText()));
                    else return new Van(nextVehicleId++, b, m, p, (int)((ComboBox)specificOptions.getChildren().get(1)).getValue(), (boolean)((ComboBox)specificOptions.getChildren().get(3)).getValue(), true);
                } catch (Exception ex) { showExceptionPopup(ex.getMessage()); }
            }
            return null;
        });
        dialog.showAndWait().ifPresent(v -> { manager.addVehicle(v); refreshVehicleDisplay(); });
    }

    private void handleRemoveVehicle() {
        Vehicle s = carList.getSelectionModel().getSelectedItem();
        if (s == null) s = bikeList.getSelectionModel().getSelectedItem();
        if (s == null) s = vanList.getSelectionModel().getSelectedItem();
        if (s != null) { try { manager.removeVehicle(s); refreshVehicleDisplay(); } catch (Exception ex) { showExceptionPopup(ex.getMessage()); }}
    }

    // ================= 2. USER PAGE =================
    private VBox createUserPage() {
        VBox layout = new VBox(15); layout.setPadding(new Insets(20));
        HBox content = new HBox(20); VBox.setVgrow(content, Priority.ALWAYS);
        userList.getSelectionModel().selectedItemProperty().addListener((obs, old, newVal) -> {
            if (newVal != null) userDetailsArea.setText("USER ID: " + newVal.getUserId() + "\nNAME: " + newVal.getName() + "\nEMAIL: " + newVal.getEmail() + "\nPHONE: " + newVal.getPhoneNumber());
            else userDetailsArea.clear();
        });
        VBox listSide = new VBox(10, new Label("Registered Users:"), userList); HBox.setHgrow(listSide, Priority.ALWAYS);
        VBox detailSide = new VBox(10, new Label("Quick View:"), userDetailsArea); userDetailsArea.setEditable(false);
        content.getChildren().addAll(listSide, detailSide);

        Button addU = new Button("Add User");
        Button remU = new Button("Remove User");
        remU.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
        addU.setOnAction(e -> openAddUserDialog());
        remU.setOnAction(e -> { User s = userList.getSelectionModel().getSelectedItem(); if (s != null) { manager.getUsers().remove(s); refreshUserDisplay(); userDetailsArea.clear(); }});

        HBox actions = new HBox(20, addU, remU); actions.setAlignment(Pos.CENTER);
        layout.getChildren().addAll(new Label("USER DIRECTORY"), content, actions);
        return layout;
    }

    private void openAddUserDialog() {
        Dialog<User> dialog = new Dialog<>();
        dialog.setTitle("New Registration");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        GridPane g = new GridPane(); g.setHgap(10); g.setVgap(10);
        TextField n = new TextField(), e = new TextField(), p = new TextField();
        g.add(new Label("Name:"), 0, 0); g.add(n, 1, 0); g.add(new Label("Email:"), 0, 1); g.add(e, 1, 1); g.add(new Label("Phone:"), 0, 2); g.add(p, 1, 2);
        dialog.getDialogPane().setContent(g);
        dialog.setResultConverter(btn -> {
            if (btn == ButtonType.OK) {
                try { return new User(nextUserId++, n.getText(), e.getText(), p.getText()); }
                catch (Exception ex) { showExceptionPopup(ex.getMessage()); }
            }
            return null;
        });
        dialog.showAndWait().ifPresent(u -> { manager.addUser(u); refreshUserDisplay(); });
    }

    // ================= 3. BOOKING PAGE =================
    private VBox createBookingPage() {
        VBox layout = new VBox(15); layout.setPadding(new Insets(20));
        VBox.setVgrow(bookingList, Priority.ALWAYS);

        Button bookBtn = new Button("New Booking");
        Button editBtn = new Button("Edit Dates");
        Button confirmBtn = new Button("Confirm Selection");
        Button cancelBtn = new Button("Cancel Selection");
        Button sortBtn = new Button("Sort (By Date)");

        confirmBtn.setStyle("-fx-background-color: #2ecc71; -fx-text-fill: white;");
        cancelBtn.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");

        bookBtn.setOnAction(e -> openAddBookingDialog());
        sortBtn.setOnAction(e -> { manager.sortBookings(); refreshBookingDisplay(); });

        editBtn.setOnAction(e -> {
            Booking s = bookingList.getSelectionModel().getSelectedItem();
            if (s != null) openEditBookingDialog(s);
            else showExceptionPopup("Please select a booking to edit.");
        });

        confirmBtn.setOnAction(e -> {
            Booking s = bookingList.getSelectionModel().getSelectedItem();
            if (s != null) { s.confirmBooking(); refreshBookingDisplay(); refreshVehicleDisplay(); }
        });

        cancelBtn.setOnAction(e -> {
            Booking s = bookingList.getSelectionModel().getSelectedItem();
            if (s != null) { 
                s.cancelBooking(); 
                refreshBookingDisplay(); 
                refreshVehicleDisplay(); 
            }
        });

        HBox actions = new HBox(15, bookBtn, editBtn, confirmBtn, cancelBtn, sortBtn);
        actions.setAlignment(Pos.CENTER);
        layout.getChildren().addAll(new Label("BOOKING MANAGEMENT"), bookingList, actions);
        return layout;
    }

    private void openAddBookingDialog() {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Create Booking");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        GridPane g = new GridPane(); g.setHgap(10); g.setVgap(10);
        ComboBox<User> uBox = new ComboBox<>(FXCollections.observableArrayList(manager.getUsers()));
        ComboBox<Vehicle> vBox = new ComboBox<>(FXCollections.observableArrayList(manager.getVehicles().stream().filter(Vehicle::isAvailable).toList()));
        DatePicker start = new DatePicker(LocalDate.now());
        DatePicker end = new DatePicker(LocalDate.now().plusDays(1));
        g.add(new Label("User:"), 0, 0); g.add(uBox, 1, 0); g.add(new Label("Vehicle:"), 0, 1); g.add(vBox, 1, 1);
        g.add(new Label("Start:"), 0, 2); g.add(start, 1, 2); g.add(new Label("End:"), 0, 3); g.add(end, 1, 3);
        dialog.getDialogPane().setContent(g);

        dialog.showAndWait().ifPresent(res -> {
            if (res == ButtonType.OK && uBox.getValue() != null && vBox.getValue() != null) {
                try {
                    manager.bookVehicle(uBox.getValue(), vBox.getValue(), start.getValue(), end.getValue());
                    refreshBookingDisplay(); refreshVehicleDisplay();
                } catch (Exception ex) { showExceptionPopup(ex.getMessage()); }
            }
        });
    }

    private void openEditBookingDialog(Booking existing) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Edit Booking #" + existing.getBookingId());
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        
        GridPane g = new GridPane(); g.setHgap(10); g.setVgap(10); g.setPadding(new Insets(20));
        DatePicker startPicker = new DatePicker(existing.getStartDate());
        DatePicker endPicker = new DatePicker(existing.getEndDate());

        g.add(new Label("New Start Date:"), 0, 0); g.add(startPicker, 1, 0);
        g.add(new Label("New End Date:"), 0, 1);   g.add(endPicker, 1, 1);
        dialog.getDialogPane().setContent(g);

        dialog.showAndWait().ifPresent(res -> {
            if (res == ButtonType.OK) {
                try {
                    // CRITICAL: Ensure your Booking class has setter methods!
                    // If your Booking class doesn't have these, you must add them to Booking.java
                    existing.setStartDate(startPicker.getValue());
                    existing.setEndDate(endPicker.getValue());
                    
                    refreshBookingDisplay();
                } catch (Exception ex) { 
                    showExceptionPopup("Error updating dates: " + ex.getMessage()); 
                }
            }
        });
    }

    // ================= HELPERS =================
    private VBox createVisibleColumn(String title, ListView<Vehicle> list) {
        VBox col = new VBox(10, new Label(title), list); col.setAlignment(Pos.TOP_CENTER); VBox.setVgrow(list, Priority.ALWAYS);
        col.setStyle("-fx-border-color: #bdc3c7; -fx-padding: 10; -fx-background-color: #ecf0f1;");
        return col;
    }

    private void refreshVehicleDisplay() {
        carList.getItems().setAll(manager.getVehicles().stream().filter(v -> v instanceof Car).toList());
        bikeList.getItems().setAll(manager.getVehicles().stream().filter(v -> v instanceof Bike).toList());
        vanList.getItems().setAll(manager.getVehicles().stream().filter(v -> v instanceof Van).toList());
    }

    private void refreshUserDisplay() { userList.getItems().setAll(manager.getUsers()); }
    private void refreshBookingDisplay() { bookingList.getItems().setAll(manager.getBookings()); }

    private void showExceptionPopup(String m) {
        Alert a = new Alert(Alert.AlertType.ERROR); a.setContentText(m); a.showAndWait();
    }

    public static void main(String[] args) { launch(args); }
}