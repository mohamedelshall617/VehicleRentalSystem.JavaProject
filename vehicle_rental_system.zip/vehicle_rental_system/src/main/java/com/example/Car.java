package com.example;

public class Car extends Vehicle {

    private int numSeats;
    private boolean hasAC;
    private TransmissionType transmissionType;
    public enum TransmissionType {
        Automatic, Manual
    }
    public enum Brand { TOYOTA, HONDA, BMW, TESLA, FORD }
    public enum Model { CAMRY, CIVIC, SERIES_3, MODEL_3, MUSTANG }
    public Car(int vehicleId, String brand, String model, double priceperday, int numSeats, boolean hasAC, TransmissionType transmissionType, boolean isAvailable) {
        super(vehicleId, brand, model, priceperday, isAvailable);
        if (numSeats <= 0) {
            throw new IllegalArgumentException("Car must have at least one seat.");
        }
        if (transmissionType == null) {
            throw new IllegalArgumentException("Transmission type cannot be null.");
        }
        this.numSeats = numSeats;
        this.hasAC = hasAC;
        this.transmissionType = transmissionType;
    }
    @Override
    void displayinfo() {
        System.out.println("Car Information:");
        System.out.println("Brand: " + super.getBrand());
        System.out.println("Model: " + super.getModel());
        System.out.println("Price per day: $" + super.getPriceperday());
        System.out.println("Number of seats: " + numSeats);
        System.out.println("Has AC: " + hasAC);
        System.out.println("Transmission type: " + transmissionType);
        System.out.println("Is available: " + super.isAvailable());
    }
    @Override
    public String toString() {
        return "Brand: " + super.getBrand() + " Model: " + super.getModel() +
                ", Number of seats=" + numSeats +
                ", Has AC=" + hasAC +
                ", Transmission type=" + transmissionType +
                ", isAvailable=" + super.isAvailable() ;
    }
} 