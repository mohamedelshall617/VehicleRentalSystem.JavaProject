package com.example;

public class Bike extends Vehicle {

    private VehicleType bikeType;
    private boolean hasHelmet;
    private int maxSpeed;
    public enum VehicleType {
        Sport, Cruiser, Touring, Standard, DualSport
    }
    public enum Brand { YAMAHA, KAWASAKI, HARLEY, DUCATI, HONDA }
    public enum Model { R1, NINJA, IRON_883, SCRAMBLER, CB500 }
    public Bike(int vehicleId, String brand, String model, double priceperday, VehicleType bikeType, boolean isAvailable, boolean hasHelmet, int maxSpeed) {
        super(vehicleId, brand, model, priceperday, isAvailable);
        if (bikeType == null) {
            throw new IllegalArgumentException("Bike type cannot be null.");
        }
        if (maxSpeed <= 0) {
            throw new IllegalArgumentException("Max speed must be greater than zero.");
        }
        this.bikeType = bikeType;
        this.hasHelmet = hasHelmet;
        this.maxSpeed = maxSpeed;
    }
    @Override
    void displayinfo() {
        System.out.println("Bike Information:");
        System.out.println("Brand: " + super.getBrand());
        System.out.println("Model: " + super.getModel());
        System.out.println("Price per day: $" + super.getPriceperday());
        System.out.println("Bike type: " + bikeType);
        System.out.println("Is available: " + super.isAvailable());
        System.out.println("Has helmet: " + hasHelmet);
        System.out.println("Max speed: " + maxSpeed + " km/h");
    }
    @Override
    public String toString() {
        return " Brand: " + super.getBrand() + " Model: " + super.getModel() +
                ", Bike type=" + bikeType +
                ", Has helmet=" + hasHelmet +
                ", Max speed=" + maxSpeed +
                ", isAvailable=" + super.isAvailable() ;
    }

} 