package com.example;

import java.time.LocalDate;

public class Booking implements Comparable<Booking> {

    private int bookingId;
    private User user;
    private Vehicle vehicle;
    private LocalDate startDate;
    private LocalDate endDate;
    private BookingStatus status;

    public enum BookingStatus {
        PENDING,
        CONFIRMED,
        CANCELLED
    }

    public Booking(int bookingId, User user, Vehicle vehicle, LocalDate startDate, LocalDate endDate) {
        if (bookingId <= 0) {
            throw new IllegalArgumentException("Booking ID must be positive.");
        }
        if (user == null) {
            throw new IllegalArgumentException("Booking must have a user.");
        }
        if (vehicle == null) {
            throw new IllegalArgumentException("Booking must have a vehicle.");
        }
        
        // Use the validation logic via the setters to keep code DRY
        setStartDate(startDate);
        setEndDate(endDate);
        
        this.bookingId = bookingId;
        this.user = user;
        this.vehicle = vehicle;
        this.status = BookingStatus.PENDING;
    }

    // --- ADDED SETTERS ---

    public void setStartDate(LocalDate startDate) {
        if (startDate == null) {
            throw new IllegalArgumentException("Start date cannot be null.");
        }
        // If an end date already exists, ensure the new start date is before it
        if (this.endDate != null && !startDate.isBefore(this.endDate)) {
            throw new IllegalArgumentException("Start date must be before the end date.");
        }
        this.startDate = startDate;
    }

    public void setEndDate(LocalDate endDate) {
        if (endDate == null) {
            throw new IllegalArgumentException("End date cannot be null.");
        }
        // Ensure end date is after the existing start date
        if (this.startDate != null && !endDate.isAfter(this.startDate)) {
            throw new IllegalArgumentException("End date must be after the start date.");
        }
        this.endDate = endDate;
    }

    // --- EXISTING METHODS ---

    public int getBookingId() { return bookingId; }
    public User getUser() { return user; }
    public Vehicle getVehicle() { return vehicle; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public BookingStatus getStatus() { return status; }

    public void confirm() { this.status = BookingStatus.CONFIRMED; }
    public void cancel() { this.status = BookingStatus.CANCELLED; }

    public int getDuration() {
        if (startDate == null || endDate == null) {
            throw new IllegalStateException("Booking dates are not set.");
        }
        long days = startDate.until(endDate).getDays();
        if (days <= 0) {
            throw new IllegalStateException("Booking duration must be at least one day.");
        }
        return (int) days;
    }

    public double calculateTotalPrice() {
        if (vehicle == null) {
            throw new IllegalStateException("Cannot calculate price for missing vehicle.");
        }
        return vehicle.getPriceperday() * getDuration();
    }

    @Override
    public int compareTo(Booking other) {
        int dateComparison = this.startDate.compareTo(other.startDate);
        if (dateComparison != 0) {
            return dateComparison;
        }
        return Integer.compare(this.bookingId, other.bookingId);
    }

    @Override
    public String toString() {
        return "Booking ID: " + bookingId +
                ", User: " + user.getName() +
                ", Vehicle: " + vehicle.getBrand() + " " + vehicle.getModel() +
                ", Start Date: " + startDate +
                ", End Date: " + endDate +
                ", Status: " + status +
                ", Total Price: $" + calculateTotalPrice();
    }

    public void confirmBooking() {
        this.status = BookingStatus.CONFIRMED;
        if (this.vehicle != null) this.vehicle.setAvailable(false);
    }

    public void cancelBooking() {
        this.status = BookingStatus.CANCELLED;
        if (this.vehicle != null) this.vehicle.setAvailable(true);
    }
}