package com.example;

public abstract class Vehicle {
    private int VehicleId;
    private String brand;
    private String model;
    private double priceperday;
    protected boolean available;
    public Vehicle(int vehicleId, String brand, String model, double priceperday, boolean available) {
        if (vehicleId <= 0) {
            throw new IllegalArgumentException("Vehicle ID must be positive.");
        }
        if (brand == null || brand.isBlank()) {
            throw new IllegalArgumentException("Vehicle brand cannot be empty.");
        }
        if (model == null || model.isBlank()) {
            throw new IllegalArgumentException("Vehicle model cannot be empty.");
        }
        if (priceperday < 0) {
            throw new IllegalArgumentException("Price per day cannot be negative.");
        }
        VehicleId = vehicleId;
        this.brand = brand;
        this.model = model;
        this.priceperday = priceperday;
        this.available = available;
    }
    boolean isAvailable() {
        return available;
    }
    void setAvailable(boolean available) {
        this.available = available;
    }
    public int getVehicleId() {
        return VehicleId;
    }
    public String getBrand() {
        return brand;
    }
    public String getModel() {
        return model;
    }
    public double getPriceperday() {
        return priceperday;
    }
    abstract void displayinfo();
    
}
