package com.example;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
public class RentableManager {

    private ArrayList<Vehicle> vehicles;
    private ArrayList<Booking> bookings;
    private ArrayList<User> users;
    private ArrayList<Payment> payments;
    private Payment.PaymentMethod paymentmethod;

    public RentableManager() {
        this.vehicles = new ArrayList<>();
        this.bookings = new ArrayList<>();
        this.users = new ArrayList<>();
        this.payments = new ArrayList<>();
    }

    public void addVehicle(Vehicle vehicle) {
        if (vehicle == null) {
            throw new IllegalArgumentException("Vehicle cannot be null.");
        }
        vehicles.add(vehicle);
    }
    public void removeVehicle(Vehicle vehicle) {
        if (vehicle == null) {
            throw new IllegalArgumentException("Vehicle cannot be null.");
        }
        if (!vehicles.remove(vehicle)) {
            throw new IllegalStateException("Vehicle not found.");
        }
    }
    public void bookVehicle(User user, Vehicle vehicle, LocalDate startDate, LocalDate endDate) {
        if (user == null) {
            throw new IllegalArgumentException("User cannot be null.");
        }
        if (vehicle == null) {
            throw new IllegalArgumentException("Vehicle cannot be null.");
        }
        if (startDate == null || endDate == null) {
            throw new IllegalArgumentException("Start date and end date are required.");
        }
        if (!vehicle.isAvailable()) {
            throw new IllegalStateException("Vehicle is not available for booking.");
        }
        Booking booking = new Booking(bookings.size() + 1, user, vehicle, startDate, endDate);
        bookings.add(booking);
        vehicle.setAvailable(false);
    }

    public void sortBookings(){
        Collections.sort(bookings);
    }
    public void processPayment(int bookingId, double amount) {
        if (bookingId <= 0) {
            throw new IllegalArgumentException("Booking ID must be positive.");
        }
        if (amount <= 0) {
            throw new IllegalArgumentException("Payment amount must be greater than zero.");
        }
        Booking booking = null;
        for (Booking item : bookings) {
            if (item.getBookingId() == bookingId) {
                booking = item;
                break;
            }
        }
        if (booking == null) {
            throw new IllegalStateException("Booking not found.");
        }
        if (paymentmethod == null) {
            throw new IllegalStateException("Payment method is not set.");
        }
        Payment payment = new Payment(payments.size() + 1, booking, amount, paymentmethod);
        payments.add(payment);
    }
    public Vehicle findVehicleById(int vehicleId) {
        if (vehicleId <= 0) {
            throw new IllegalArgumentException("Vehicle ID must be positive.");
        }
        for (Vehicle vehicle : vehicles) {
            if (vehicle.getVehicleId() == vehicleId) {
                return vehicle;
            }
        }
        return null;
    }
    public void displayAvailableVehicles() {
        for (Vehicle vehicle : vehicles) {
            if (vehicle.isAvailable()) {
                vehicle.displayinfo();
            }
        }
    }
    public ArrayList<Vehicle> getVehicles() {
        return vehicles;
    }

    public ArrayList<Booking> getBookings() {
        return bookings;
    }

    public ArrayList<User> getUsers() {
        return users;
    }

    public ArrayList<Payment> getPayments() {
        return payments;
    }
    public void addUser(User user) {
    if (user == null) {
        throw new IllegalArgumentException("User cannot be null.");
    }
    users.add(user);
    }

    public void cancelBooking(int bookingId) {
        for (Booking b : bookings) {
            if (b.getBookingId() == bookingId) {
                b.cancelBooking();
                break;
            }
        }
    }
    
}