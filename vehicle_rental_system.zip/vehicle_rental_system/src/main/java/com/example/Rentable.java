package com.example;

public interface Rentable {
    public void rent();
}
